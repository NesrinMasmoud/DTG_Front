export class Role {
    roleId:string="";
    roleName:string;
}
