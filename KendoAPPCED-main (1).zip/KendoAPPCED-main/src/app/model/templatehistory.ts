export class TemplateHistory {
    TemplateHistoryCreatedBy:string="";
    Content:string;
    TemplateId: string="";
}