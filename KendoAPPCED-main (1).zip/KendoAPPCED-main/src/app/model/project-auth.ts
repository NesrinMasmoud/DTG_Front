export class ProjectAuth {
    projectAuthorizationId:string="";
    read:string;
    write:string;
    employeeId:string;
    projectId:string;
}
