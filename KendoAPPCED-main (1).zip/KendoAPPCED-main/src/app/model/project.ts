export class Project {
    projectId:string="";
    projectName:string;
    createdBy:string;
    createdDate? :Date;
}
